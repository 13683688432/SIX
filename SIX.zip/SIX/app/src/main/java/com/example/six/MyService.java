package com.example.six;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.renderscript.Sampler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.util.zip.Inflater;

public class MyService extends Service {

    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        double shu1 = Double.parseDouble(intent.getStringExtra("shuzi1"));
        double shu2 = Double.parseDouble(intent.getStringExtra("shuzi2"));
        String yunsuanfu = intent.getStringExtra("yunsuanfu");
        if(yunsuanfu.equals("+")){
            Intent i = new Intent(MyService.this,MainActivity.class);
            double m = shu1+shu2;
            i.putExtra("jieguo",m+"");
            Log.d("计算结果为：   ",m+"");
        }
        if(yunsuanfu.equals("-")){
            Intent i = new Intent(MyService.this,MainActivity.class);
            double m = shu1-shu2;
            i.putExtra("jieguo",m+"");
            Log.d("计算结果为：   ",m+"");
        }
        if(yunsuanfu.equals("*")){
            Intent i = new Intent(MyService.this,MainActivity.class);
            double m = shu1*shu2;
            i.putExtra("jieguo",m+"");
            Log.d("计算结果为：   ",m+"");
        }
        if(yunsuanfu.equals("/")){
            Intent i = new Intent(MyService.this,MainActivity.class);
            double m = shu1/shu2;
            i.putExtra("jieguo",m+"");
            Log.d("计算结果为：   ",m+"");
        }

        return super.onStartCommand(intent, flags, startId);
    }
}
