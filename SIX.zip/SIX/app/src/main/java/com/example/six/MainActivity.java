package com.example.six;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button jia,jian,cheng,chu;
        jia = findViewById(R.id.jia);
        jian = findViewById(R.id.jian);
        cheng = findViewById(R.id.cheng);
        chu = findViewById(R.id.chu);
        jia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuzi1 = findViewById(R.id.shuzi1);
                EditText shuzi2 = findViewById(R.id.shuzi2);
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("shuzi1",shuzi1.getText().toString());
                intent.putExtra("yunsuanfu","+");
                intent.putExtra("shuzi2",shuzi2.getText().toString());
                startService(intent);
                //传入三个数字
            }
        });
        jian.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuzi1 = findViewById(R.id.shuzi1);
                EditText shuzi2 = findViewById(R.id.shuzi2);
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("shuzi1",shuzi1.getText().toString());
                intent.putExtra("yunsuanfu","-");
                intent.putExtra("shuzi2",shuzi2.getText().toString());
                startService(intent);
                //传入三个数字
            }
        });
        cheng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuzi1 = findViewById(R.id.shuzi1);
                EditText shuzi2 = findViewById(R.id.shuzi2);
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("shuzi1",shuzi1.getText().toString());
                intent.putExtra("yunsuanfu","*");
                intent.putExtra("shuzi2",shuzi2.getText().toString());
                startService(intent);
                //传入三个数字
            }
        });
        chu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText shuzi1 = findViewById(R.id.shuzi1);
                EditText shuzi2 = findViewById(R.id.shuzi2);
                Intent intent = new Intent(MainActivity.this, MyService.class);
                intent.putExtra("shuzi1",shuzi1.getText().toString());
                intent.putExtra("yunsuanfu","/");
                intent.putExtra("shuzi2",shuzi2.getText().toString());
                startService(intent);
                //传入三个数字
            }
        });

        final Handler handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {

                if(msg.arg1==1) {
                    TextView shuchu = findViewById(R.id.shuchu);
                    shuchu.setText("该数是素数");

                }
                else {
                    TextView shuchu = findViewById(R.id.shuchu);
                    shuchu.setText("该数不是素数");
                }
            }
        };

        final Runnable myWorker = new Runnable() {
            @Override
            public void run() {
                int m = 1;   //m=1为素数
                int i=2;
                EditText sushu = findViewById(R.id.sushu);

                int j = Integer.parseInt(sushu.getText().toString());
                while(i<j){
                    if(j%i==0) {
                        m = 0;    //为0不是素数
                        break;
                    }
                    else{
                        i++;
                    }
                    try {
                        Thread.sleep(200); //这里每次运算之间空200毫秒
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if(m==1) {
                    Message msg = handler.obtainMessage();//同 new Message();
                    msg.arg1 = 1;    //
                    handler.sendMessage(msg);
                }
                else if(m==0){
                    Message msg = new Message();
                    msg.arg1 = 0;
                    handler.sendMessage(msg);
                }

            }
        };
        Button panduan = (Button) findViewById(R.id.panduan);
        panduan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread workThread = new Thread(null, myWorker, "WorkThread");
                workThread.start();

            }
        });
    }

    }

